# SuperShop

Animated Paper shop plugin (Vault-compatible, built-in economy fallback).

## Build
1. Install JDK 21 (or whatever your Paper version needs) and Maven.
2. In `pom.xml` set `<paper.version>` to match your server (e.g. `1.21.11-R0.1-SNAPSHOT`)
   and in `plugin.yml` set `api-version`.
3. Run: `mvn clean package` -> `target/SuperShop-1.0.0.jar`
4. Drop the jar in `plugins/` and restart.

## Use
- `/shop` open the menu - `/sell hand|all` - `/balance`
- `/shop reload`, `/shop give <player> <amount>` (admin; give only for built-in economy)
- Click: Left = buy 1, Shift+Left = buy a stack, Right = sell 1, Shift+Right = sell all

Edit `plugins/SuperShop/shop.yml` to add categories/items, `config.yml` for text & colours (MiniMessage).
