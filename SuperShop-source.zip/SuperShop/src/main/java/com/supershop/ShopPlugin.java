package com.supershop;

import com.supershop.economy.InternalEconomy;
import com.supershop.economy.ShopEconomy;
import com.supershop.economy.VaultEconomy;
import com.supershop.gui.GuiListener;
import com.supershop.gui.Menu;
import com.supershop.shop.ShopManager;
import com.supershop.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Locale;

public final class ShopPlugin extends JavaPlugin {
    private ShopEconomy economy;
    private ShopManager shop;
    private int frame;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        saveResource("shop.yml", false);

        economy = new InternalEconomy(this);
        shop = new ShopManager(this);
        shop.load();

        Bukkit.getPluginManager().registerEvents(new GuiListener(), this);
        ShopCommand cmd = new ShopCommand(this);
        for (String name : new String[]{"shop", "sell", "balance"}) {
            getCommand(name).setExecutor(cmd);
            getCommand(name).setTabCompleter(cmd);
        }

        // Runs after every plugin has enabled, so Vault's economy provider is registered by then.
        Bukkit.getScheduler().runTask(this, () -> {
            VaultEconomy vault = VaultEconomy.create();
            if (vault != null) economy = vault;
            getLogger().info("Using economy: " + economy.name());
        });

        // Border animation
        int speed = Math.max(1, getConfig().getInt("menu.animation-speed-ticks", 4));
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            frame++;
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.getOpenInventory().getTopInventory().getHolder(false) instanceof Menu m) m.tick(frame);
            }
        }, speed, speed);

        // Autosave the built-in economy every 5 minutes
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            if (economy instanceof InternalEconomy ie) ie.save();
        }, 6000L, 6000L);
    }

    @Override
    public void onDisable() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.getOpenInventory().getTopInventory().getHolder(false) instanceof Menu) p.closeInventory();
        }
        if (economy instanceof InternalEconomy ie) ie.save();
    }

    public void reloadAll() {
        reloadConfig();
        shop.load();
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.getOpenInventory().getTopInventory().getHolder(false) instanceof Menu) p.closeInventory();
        }
    }

    public ShopEconomy economy() { return economy; }
    public ShopManager shop() { return shop; }

    // ------------------------------------------------------------ helpers

    public String money(double amount) {
        return getConfig().getString("currency-symbol", "$") + String.format(Locale.US, "%,.2f", amount);
    }

    private String message(String key, String... kv) {
        String s = getConfig().getString("messages." + key, key);
        for (int i = 0; i + 1 < kv.length; i += 2) s = s.replace(kv[i], kv[i + 1]);
        return s;
    }

    /** Chat message with prefix. */
    public void send(CommandSender to, String key, String... kv) {
        to.sendMessage(Text.mm(getConfig().getString("messages.prefix", "") + message(key, kv)));
    }

    /** Action-bar message (no chat spam while shopping). */
    public void bar(Player to, String key, String... kv) {
        to.sendActionBar(Text.mm(message(key, kv)));
    }

    public void click(Player p) { p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 0.6f, 1.2f); }
    public void success(Player p) { p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.8f, 1.3f); }
    public void deny(Player p) { p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, 0.8f, 1f); }
}
