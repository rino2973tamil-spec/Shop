package com.supershop.shop;

import org.bukkit.Material;

public record ShopItem(Material material, double buy, double sell) {
    public boolean canBuy() { return buy >= 0; }
    public boolean canSell() { return sell >= 0; }
}
