package com.supershop.shop;

import com.supershop.ShopPlugin;
import com.supershop.economy.ShopEconomy;
import com.supershop.util.Text;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.util.*;

public final class ShopManager {
    private final ShopPlugin plugin;
    private final Map<String, ShopCategory> categories = new LinkedHashMap<>();
    private final Map<Material, ShopItem> byMaterial = new EnumMap<>(Material.class);

    public ShopManager(ShopPlugin plugin) {
        this.plugin = plugin;
    }

    public Collection<ShopCategory> categories() { return categories.values(); }
    public ShopItem find(Material m) { return byMaterial.get(m); }

    public void load() {
        categories.clear();
        byMaterial.clear();
        File f = new File(plugin.getDataFolder(), "shop.yml");
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(f);
        ConfigurationSection root = cfg.getConfigurationSection("categories");
        if (root == null) {
            plugin.getLogger().warning("shop.yml has no 'categories' section!");
            return;
        }
        for (String id : root.getKeys(false)) {
            ConfigurationSection c = root.getConfigurationSection(id);
            if (c == null) continue;
            Material icon = Material.matchMaterial(c.getString("icon", "CHEST"));
            if (icon == null) icon = Material.CHEST;
            List<ShopItem> items = new ArrayList<>();
            for (Map<?, ?> m : c.getMapList("items")) {
                Object raw = m.get("material");
                Material mat = raw == null ? null : Material.matchMaterial(String.valueOf(raw));
                if (mat == null || !mat.isItem() || mat.isAir()) {
                    plugin.getLogger().warning("Skipping unknown material '" + raw + "' in category " + id);
                    continue;
                }
                ShopItem item = new ShopItem(mat, num(m.get("buy")), num(m.get("sell")));
                items.add(item);
                byMaterial.putIfAbsent(mat, item);
            }
            categories.put(id, new ShopCategory(id, c.getString("name", id), icon,
                    c.getInt("slot", 20), c.getStringList("description"), items));
        }
        plugin.getLogger().info("Loaded " + categories.size() + " categories, " + byMaterial.size() + " items.");
    }

    private static double num(Object o) {
        if (o instanceof Number n) return n.doubleValue();
        if (o != null) {
            try { return Double.parseDouble(o.toString()); } catch (NumberFormatException ignored) {}
        }
        return -1;
    }

    // ---------------------------------------------------------------- inventory helpers

    private static boolean plain(ItemStack s, Material m) {
        return s != null && s.getType() == m && !s.hasItemMeta();
    }

    public int count(Player p, Material m) {
        int total = 0;
        for (ItemStack s : p.getInventory().getStorageContents()) if (plain(s, m)) total += s.getAmount();
        return total;
    }

    private void remove(Player p, Material m, int amount) {
        ItemStack[] contents = p.getInventory().getStorageContents();
        for (int i = 0; i < contents.length && amount > 0; i++) {
            if (!plain(contents[i], m)) continue;
            int take = Math.min(amount, contents[i].getAmount());
            amount -= take;
            if (take == contents[i].getAmount()) contents[i] = null;
            else contents[i].setAmount(contents[i].getAmount() - take);
        }
        p.getInventory().setStorageContents(contents);
    }

    // ---------------------------------------------------------------- transactions

    public void buy(Player p, ShopItem item, int amount) {
        if (!item.canBuy()) { plugin.bar(p, "not-buyable"); plugin.deny(p); return; }
        ShopEconomy eco = plugin.economy();
        double total = item.buy() * amount;
        if (!eco.has(p, total)) {
            plugin.bar(p, "not-enough-money", "%price%", plugin.money(total));
            plugin.deny(p);
            return;
        }
        if (!eco.withdraw(p, total)) { plugin.deny(p); return; }

        int max = item.material().getMaxStackSize();
        List<ItemStack> stacks = new ArrayList<>();
        for (int rem = amount; rem > 0; ) {
            int n = Math.min(rem, max);
            stacks.add(new ItemStack(item.material(), n));
            rem -= n;
        }
        int left = 0;
        for (ItemStack s : p.getInventory().addItem(stacks.toArray(new ItemStack[0])).values()) left += s.getAmount();
        if (left > 0) eco.deposit(p, left * item.buy()); // refund what didn't fit
        int given = amount - left;
        if (given <= 0) { plugin.bar(p, "inventory-full"); plugin.deny(p); return; }

        plugin.bar(p, "bought", "%amount%", String.valueOf(given),
                "%item%", Text.pretty(item.material()), "%price%", plugin.money(given * item.buy()));
        plugin.success(p);
    }

    public void sell(Player p, ShopItem item, int amount, boolean all) {
        if (!item.canSell()) { plugin.bar(p, "not-sellable"); plugin.deny(p); return; }
        int have = count(p, item.material());
        int n = all ? have : Math.min(amount, have);
        if (n <= 0) { plugin.bar(p, "nothing-to-sell"); plugin.deny(p); return; }
        remove(p, item.material(), n);
        double total = n * item.sell();
        plugin.economy().deposit(p, total);
        plugin.bar(p, "sold", "%amount%", String.valueOf(n),
                "%item%", Text.pretty(item.material()), "%price%", plugin.money(total));
        plugin.success(p);
    }

    /** Sell the stack in the main hand. Returns true if something was sold. */
    public boolean sellHand(Player p) {
        ItemStack hand = p.getInventory().getItemInMainHand();
        ShopItem item = hand.getType().isAir() || hand.hasItemMeta() ? null : find(hand.getType());
        if (item == null || !item.canSell()) { plugin.bar(p, "hold-item"); plugin.deny(p); return false; }
        int n = hand.getAmount();
        p.getInventory().setItemInMainHand(null);
        double total = n * item.sell();
        plugin.economy().deposit(p, total);
        plugin.bar(p, "sold", "%amount%", String.valueOf(n),
                "%item%", Text.pretty(item.material()), "%price%", plugin.money(total));
        plugin.success(p);
        return true;
    }

    /** Sell everything sellable in the inventory. */
    public void sellAll(Player p) {
        ItemStack[] contents = p.getInventory().getStorageContents();
        int count = 0;
        double total = 0;
        for (int i = 0; i < contents.length; i++) {
            ItemStack s = contents[i];
            if (s == null || s.hasItemMeta()) continue;
            ShopItem item = find(s.getType());
            if (item == null || !item.canSell()) continue;
            count += s.getAmount();
            total += s.getAmount() * item.sell();
            contents[i] = null;
        }
        if (count == 0) { plugin.bar(p, "nothing-to-sell"); plugin.deny(p); return; }
        p.getInventory().setStorageContents(contents);
        plugin.economy().deposit(p, total);
        plugin.bar(p, "sold-all", "%count%", String.valueOf(count), "%price%", plugin.money(total));
        plugin.success(p);
    }
}
