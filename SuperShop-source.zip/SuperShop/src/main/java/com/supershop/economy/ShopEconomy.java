package com.supershop.economy;

import org.bukkit.entity.Player;

public interface ShopEconomy {
    double balance(Player player);
    boolean has(Player player, double amount);
    boolean withdraw(Player player, double amount);
    void deposit(Player player, double amount);
    String name();
}
