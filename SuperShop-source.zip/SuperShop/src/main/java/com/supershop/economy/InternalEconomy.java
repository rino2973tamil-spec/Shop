package com.supershop.economy;

import com.supershop.ShopPlugin;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Simple built-in economy used when Vault is not installed. */
public final class InternalEconomy implements ShopEconomy {
    private final ShopPlugin plugin;
    private final File file;
    private final Map<UUID, Double> balances = new HashMap<>();
    private final double start;

    public InternalEconomy(ShopPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "balances.yml");
        this.start = plugin.getConfig().getDouble("starting-balance", 1000.0);
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        for (String key : y.getKeys(false)) {
            try {
                balances.put(UUID.fromString(key), y.getDouble(key));
            } catch (IllegalArgumentException ignored) {}
        }
    }

    public void save() {
        YamlConfiguration y = new YamlConfiguration();
        balances.forEach((id, bal) -> y.set(id.toString(), bal));
        try {
            y.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("Could not save balances: " + e.getMessage());
        }
    }

    @Override public double balance(Player p) { return balances.getOrDefault(p.getUniqueId(), start); }
    @Override public boolean has(Player p, double amount) { return balance(p) + 1e-9 >= amount; }

    @Override
    public boolean withdraw(Player p, double amount) {
        if (!has(p, amount)) return false;
        balances.put(p.getUniqueId(), balance(p) - amount);
        return true;
    }

    @Override
    public void deposit(Player p, double amount) {
        balances.put(p.getUniqueId(), balance(p) + amount);
    }

    @Override public String name() { return "Built-in"; }
}
