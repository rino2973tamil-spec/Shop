package com.supershop.economy;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;

public final class VaultEconomy implements ShopEconomy {
    private final Economy eco;

    private VaultEconomy(Economy eco) {
        this.eco = eco;
    }

    /** Returns null when Vault or an economy provider is missing. */
    public static VaultEconomy create() {
        if (Bukkit.getPluginManager().getPlugin("Vault") == null) return null;
        RegisteredServiceProvider<Economy> rsp = Bukkit.getServicesManager().getRegistration(Economy.class);
        return rsp == null ? null : new VaultEconomy(rsp.getProvider());
    }

    @Override public double balance(Player p) { return eco.getBalance(p); }
    @Override public boolean has(Player p, double amount) { return eco.has(p, amount); }
    @Override public boolean withdraw(Player p, double amount) { return eco.withdrawPlayer(p, amount).transactionSuccess(); }
    @Override public void deposit(Player p, double amount) { eco.depositPlayer(p, amount); }
    @Override public String name() { return "Vault (" + eco.getName() + ")"; }
}
