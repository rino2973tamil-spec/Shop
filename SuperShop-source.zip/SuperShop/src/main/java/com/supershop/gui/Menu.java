package com.supershop.gui;

import com.supershop.ShopPlugin;
import com.supershop.util.ItemBuilder;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;

import java.util.*;

/** Base class for all 6-row shop menus. Draws a rainbow border that flows around the edge. */
public abstract class Menu implements InventoryHolder {
    protected static final int SIZE = 54;

    /** Border slots in clockwise order, so colours appear to travel around the menu. */
    private static final List<Integer> PERIMETER = new ArrayList<>();
    private static final Set<Integer> BORDER = new HashSet<>();

    private static final Material[] COLORS = {
            Material.PURPLE_STAINED_GLASS_PANE, Material.MAGENTA_STAINED_GLASS_PANE,
            Material.PINK_STAINED_GLASS_PANE, Material.RED_STAINED_GLASS_PANE,
            Material.ORANGE_STAINED_GLASS_PANE, Material.YELLOW_STAINED_GLASS_PANE,
            Material.LIME_STAINED_GLASS_PANE, Material.CYAN_STAINED_GLASS_PANE,
            Material.LIGHT_BLUE_STAINED_GLASS_PANE, Material.BLUE_STAINED_GLASS_PANE
    };
    private static final Map<Material, ItemStack> PANES = new EnumMap<>(Material.class);
    private static final ItemStack BACKGROUND = pane(Material.BLACK_STAINED_GLASS_PANE);

    static {
        for (int i = 0; i <= 8; i++) PERIMETER.add(i);
        for (int r = 1; r <= 4; r++) PERIMETER.add(r * 9 + 8);
        for (int i = 53; i >= 45; i--) PERIMETER.add(i);
        for (int r = 4; r >= 1; r--) PERIMETER.add(r * 9);
        BORDER.addAll(PERIMETER);
        for (Material m : COLORS) PANES.put(m, pane(m));
    }

    private static ItemStack pane(Material m) {
        return new ItemBuilder(m).name(" ").build();
    }

    protected final ShopPlugin plugin;
    protected final Player player;
    protected final Inventory inventory;
    /** Slots occupied by buttons - the animation skips these. */
    protected final Set<Integer> reserved = new HashSet<>();
    private int frame;

    protected Menu(ShopPlugin plugin, Player player, Component title) {
        this.plugin = plugin;
        this.player = player;
        this.inventory = Bukkit.createInventory(this, SIZE, title);
    }

    protected abstract void build();

    public abstract void click(InventoryClickEvent e);

    public void open() {
        refresh();
        player.openInventory(inventory);
        plugin.click(player);
    }

    protected void refresh() {
        build();
        animate();
    }

    public void tick(int frame) {
        this.frame = frame;
        animate();
    }

    private void animate() {
        for (int i = 0; i < PERIMETER.size(); i++) {
            int slot = PERIMETER.get(i);
            if (reserved.contains(slot)) continue;
            inventory.setItem(slot, PANES.get(COLORS[Math.floorMod(i - frame, COLORS.length)]));
        }
    }

    protected void fillBackground() {
        for (int i = 0; i < SIZE; i++) if (!BORDER.contains(i)) inventory.setItem(i, BACKGROUND);
    }

    protected ItemStack background() {
        return BACKGROUND;
    }

    protected ItemStack balanceItem() {
        return new ItemBuilder(Material.PLAYER_HEAD)
                .head(player)
                .name("<gradient:#f5af19:#f12711><bold>✦ Your Balance</bold></gradient>")
                .lore("", "<gray>Wallet: <gold>" + plugin.money(plugin.economy().balance(player)), "",
                        "<dark_gray>Powered by " + plugin.economy().name())
                .glow()
                .build();
    }

    @Override
    public @NotNull Inventory getInventory() {
        return inventory;
    }
}
