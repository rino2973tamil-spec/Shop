package com.supershop.gui;

import com.supershop.ShopPlugin;
import com.supershop.shop.ShopCategory;
import com.supershop.util.ItemBuilder;
import com.supershop.util.Text;
import org.bukkit.Material;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.ArrayList;
import java.util.List;

public final class MainMenu extends Menu {

    public MainMenu(ShopPlugin plugin, org.bukkit.entity.Player player) {
        super(plugin, player, Text.mm(plugin.getConfig().getString("menu.main-title", "Shop")));
    }

    @Override
    protected void build() {
        reserved.clear();
        reserved.add(4);
        reserved.add(48);
        reserved.add(49);
        reserved.add(50);
        fillBackground();

        inventory.setItem(4, balanceItem());
        for (ShopCategory c : plugin.shop().categories()) {
            reserved.add(c.slot());
            List<String> lore = new ArrayList<>();
            lore.add("");
            lore.addAll(c.description());
            lore.add("");
            lore.add("<gray>Items: <white>" + c.items().size());
            lore.add("");
            lore.add("<yellow>▶ Click to browse");
            inventory.setItem(c.slot(), new ItemBuilder(c.icon()).name("<bold>" + c.name() + "</bold>")
                    .lore(lore).glow().build());
        }

        inventory.setItem(48, new ItemBuilder(Material.GOLD_NUGGET)
                .name("<gradient:#f5af19:#ffd200><bold>Sell Hand</bold></gradient>")
                .lore("", "<gray>Sell the stack you're", "<gray>holding right now.", "", "<yellow>▶ Click to sell").build());
        inventory.setItem(49, new ItemBuilder(Material.BARRIER)
                .name("<red><bold>Close</bold>").build());
        inventory.setItem(50, new ItemBuilder(Material.HOPPER)
                .name("<gradient:#56ab2f:#a8e063><bold>Sell Inventory</bold></gradient>")
                .lore("", "<gray>Sell every sellable item", "<gray>in your inventory.", "", "<yellow>▶ Click to sell all").build());
    }

    @Override
    public void click(InventoryClickEvent e) {
        int slot = e.getSlot();
        switch (slot) {
            case 49 -> player.closeInventory();
            case 48 -> {
                plugin.shop().sellHand(player);
                inventory.setItem(4, balanceItem());
            }
            case 50 -> {
                plugin.shop().sellAll(player);
                inventory.setItem(4, balanceItem());
            }
            default -> {
                for (ShopCategory c : plugin.shop().categories()) {
                    if (c.slot() == slot) {
                        new CategoryMenu(plugin, player, c).open();
                        return;
                    }
                }
            }
        }
    }
}
