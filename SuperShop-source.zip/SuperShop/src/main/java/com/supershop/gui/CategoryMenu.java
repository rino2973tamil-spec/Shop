package com.supershop.gui;

import com.supershop.ShopPlugin;
import com.supershop.shop.ShopCategory;
import com.supershop.shop.ShopItem;
import com.supershop.util.ItemBuilder;
import com.supershop.util.Text;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.util.List;

public final class CategoryMenu extends Menu {
    private static final int[] ITEM_SLOTS = new int[28];

    static {
        int n = 0;
        for (int row = 1; row <= 4; row++)
            for (int col = 1; col <= 7; col++) ITEM_SLOTS[n++] = row * 9 + col;
    }

    private final ShopCategory category;
    private int page = 0;

    public CategoryMenu(ShopPlugin plugin, Player player, ShopCategory category) {
        super(plugin, player, Text.mm(plugin.getConfig().getString("menu.category-title", "%category%")
                .replace("%category%", category.name())));
        this.category = category;
    }

    private int pages() {
        return Math.max(1, (int) Math.ceil(category.items().size() / (double) ITEM_SLOTS.length));
    }

    @Override
    protected void build() {
        int pages = pages();
        if (page >= pages) page = pages - 1;

        reserved.clear();
        reserved.add(4);
        reserved.add(48);
        reserved.add(50);
        if (page > 0) reserved.add(45);
        if (page < pages - 1) reserved.add(53);
        fillBackground();

        inventory.setItem(4, balanceItem());
        inventory.setItem(48, new ItemBuilder(Material.ARROW)
                .name("<red><bold>← Back</bold>").lore("", "<gray>Return to the main menu").build());
        inventory.setItem(50, new ItemBuilder(Material.PAPER)
                .name("<white>Page <yellow>" + (page + 1) + "<gray>/<yellow>" + pages).build());
        if (page > 0) inventory.setItem(45, new ItemBuilder(Material.SPECTRAL_ARROW)
                .name("<yellow><bold>« Previous Page</bold>").build());
        if (page < pages - 1) inventory.setItem(53, new ItemBuilder(Material.SPECTRAL_ARROW)
                .name("<yellow><bold>Next Page »</bold>").build());

        List<ShopItem> items = category.items();
        for (int i = 0; i < ITEM_SLOTS.length; i++) {
            int idx = page * ITEM_SLOTS.length + i;
            inventory.setItem(ITEM_SLOTS[i], idx < items.size() ? display(items.get(idx)) : background());
        }
    }

    private ItemStack display(ShopItem it) {
        String buy = it.canBuy() ? "<green>" + plugin.money(it.buy()) : "<red>Not for sale";
        String sell = it.canSell() ? "<gold>" + plugin.money(it.sell()) : "<red>Can't be sold";
        ItemBuilder b = new ItemBuilder(it.material())
                .name("<white><bold>" + Text.pretty(it.material()) + "</bold>")
                .lore("",
                        "<gray>Buy price: " + buy,
                        "<gray>Sell price: " + sell,
                        "",
                        "<gray>You own: <white>" + plugin.shop().count(player, it.material()),
                        "");
        if (it.canBuy())
            b.lore("<yellow>Left-click <gray>» Buy <white>1", "<yellow>Shift+Left <gray>» Buy <white>stack");
        if (it.canSell())
            b.lore("<yellow>Right-click <gray>» Sell <white>1", "<yellow>Shift+Right <gray>» Sell <white>all");
        return b.build();
    }

    @Override
    public void click(InventoryClickEvent e) {
        int slot = e.getSlot();
        if (slot == 48) {
            new MainMenu(plugin, player).open();
            return;
        }
        if (slot == 45 && page > 0) {
            page--;
            refresh();
            plugin.click(player);
            return;
        }
        if (slot == 53 && page < pages() - 1) {
            page++;
            refresh();
            plugin.click(player);
            return;
        }

        int pos = -1;
        for (int i = 0; i < ITEM_SLOTS.length; i++) if (ITEM_SLOTS[i] == slot) pos = i;
        if (pos < 0) return;
        int idx = page * ITEM_SLOTS.length + pos;
        if (idx >= category.items().size()) return;

        ShopItem item = category.items().get(idx);
        ClickType type = e.getClick();
        switch (type) {
            case LEFT -> plugin.shop().buy(player, item, 1);
            case SHIFT_LEFT -> plugin.shop().buy(player, item, item.material().getMaxStackSize());
            case RIGHT -> plugin.shop().sell(player, item, 1, false);
            case SHIFT_RIGHT -> plugin.shop().sell(player, item, 0, true);
            default -> { return; }
        }
        refresh(); // update balance + "You own" counters
    }
}
