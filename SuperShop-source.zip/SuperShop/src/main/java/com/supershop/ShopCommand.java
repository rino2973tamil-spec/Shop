package com.supershop;

import com.supershop.gui.MainMenu;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

public final class ShopCommand implements CommandExecutor, TabCompleter {
    private final ShopPlugin plugin;

    public ShopCommand(ShopPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command cmd, @NotNull String label, @NotNull String[] args) {
        switch (cmd.getName().toLowerCase()) {
            case "shop" -> {
                if (args.length >= 1 && args[0].equalsIgnoreCase("reload")) {
                    if (!sender.hasPermission("supershop.admin")) { plugin.send(sender, "no-permission"); return true; }
                    plugin.reloadAll();
                    plugin.send(sender, "reloaded");
                    return true;
                }
                if (args.length >= 3 && args[0].equalsIgnoreCase("give")) {
                    if (!sender.hasPermission("supershop.admin")) { plugin.send(sender, "no-permission"); return true; }
                    Player target = Bukkit.getPlayerExact(args[1]);
                    if (target == null) { sender.sendMessage("Player not found."); return true; }
                    try {
                        double amt = Double.parseDouble(args[2]);
                        plugin.economy().deposit(target, amt);
                        plugin.send(sender, "gave", "%price%", plugin.money(amt), "%player%", target.getName());
                    } catch (NumberFormatException ex) {
                        sender.sendMessage("Invalid amount.");
                    }
                    return true;
                }
                if (!(sender instanceof Player p)) { plugin.send(sender, "player-only"); return true; }
                if (!p.hasPermission("supershop.use")) { plugin.send(p, "no-permission"); return true; }
                new MainMenu(plugin, p).open();
            }
            case "sell" -> {
                if (!(sender instanceof Player p)) { plugin.send(sender, "player-only"); return true; }
                if (!p.hasPermission("supershop.use")) { plugin.send(p, "no-permission"); return true; }
                if (args.length == 0) { plugin.send(p, "usage-sell"); return true; }
                switch (args[0].toLowerCase()) {
                    case "hand" -> plugin.shop().sellHand(p);
                    case "all" -> plugin.shop().sellAll(p);
                    default -> plugin.send(p, "usage-sell");
                }
            }
            case "balance" -> {
                if (!(sender instanceof Player p)) { plugin.send(sender, "player-only"); return true; }
                plugin.send(p, "balance", "%balance%", plugin.money(plugin.economy().balance(p)));
            }
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command cmd, @NotNull String alias, @NotNull String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length != 1) return out;
        if (cmd.getName().equalsIgnoreCase("sell")) { out.add("hand"); out.add("all"); }
        if (cmd.getName().equalsIgnoreCase("shop") && sender.hasPermission("supershop.admin")) { out.add("reload"); out.add("give"); }
        out.removeIf(s -> !s.startsWith(args[0].toLowerCase()));
        return out;
    }
}
